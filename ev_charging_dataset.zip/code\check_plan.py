"""Independently check the greedy baseline plan stored in each instance.json
against the constraints of main_formulation (minutes, km, kWh).

Usage:  python check_plan.py <instances_dir>
"""
import glob
import json
import os
import sys

import numpy as np

EPS = 1e-6


def check(path):
    J = json.load(open(path))
    p, ev, g = J["params"], J["ev"], J["greedy_baseline"]
    n, T = J["n_ev"], p["T_min"]
    r, E, R, w = map(np.array, (ev["r_min"], ev["E_kWh"], ev["R_km"], ev["w"]))
    tF, tM = np.array(ev["tauF_min"]), np.array(ev["tauM_min"])
    dEF, tEF = np.array(J["d_ev_fcs_km"]), np.array(J["t_ev_fcs_min"])
    dN, tN = np.array(J["d_nodes_km"]), np.array(J["t_nodes_min"])
    S, C, res = np.array(g["S"]), np.array(g["C"]), g["resource"]
    err = []
    gun_jobs = {}
    on_van = set()
    for i in range(n):                                   # (2) one resource each
        if res[i].startswith("FCS"):
            f = int(res[i][3:res[i].index("-")]) - 1
            if dEF[i, f] > R[i] + EPS:
                err.append(f"EV{i+1} cannot reach FCS{f+1}")
            if S[i] < r[i] + tEF[i, f] - EPS:            # (3)
                err.append(f"EV{i+1} starts before arriving")
            if abs(C[i] - S[i] - tF[i]) > 1e-3:
                err.append(f"EV{i+1} wrong FCS duration")
            gun_jobs.setdefault(res[i], []).append((S[i], C[i], i))
        else:
            on_van.add(i + 1)
        if C[i] > T + EPS:                               # (18)
            err.append(f"EV{i+1} finishes after T")
    for gun, jobs in gun_jobs.items():                   # (4)-(5) no overlap
        jobs.sort()
        for a, b in zip(jobs, jobs[1:]):
            if b[0] < a[1] - EPS:
                err.append(f"overlap on {gun}: EV{a[2]+1} and EV{b[2]+1}")
    seen = set()
    for route in g["van_routes"]:                        # (7)-(16)
        stops = route[1:-1]
        seen |= set(stops)
        if len(stops) > p["Q"]:
            err.append("Q exceeded")
        km = sum(dN[a, b] for a, b in zip(route, route[1:]))
        energy = sum(E[k - 1] / p["eta"] for k in stops) + p["beta_kWh_per_km"] * km
        if energy > p["B_kWh"] + EPS:
            err.append(f"battery exceeded on route {route}")
        t, pos = 0.0, 0
        for k in stops:
            i = k - 1
            start = max(r[i], t + tN[pos, k])
            if abs(start - S[i]) > 1e-3 or abs(C[i] - S[i] - tM[i]) > 1e-3:
                err.append(f"van timing wrong at EV{k}")
            t, pos = C[i], k
        if t + tN[pos, 0] > T + EPS:
            err.append(f"van back after T on route {route}")
    if seen != on_van:
        err.append("van EVs not visited exactly once")
    # objective recomputed from scratch
    c = p["costs_Rs"]
    Z1 = c["c_EV"] * sum(dEF[i, int(res[i][3:res[i].index("-")]) - 1]
                         for i in range(n) if res[i].startswith("FCS"))
    Z2 = c["c_M"] * sum(sum(dN[a, b] for a, b in zip(rt, rt[1:])) for rt in g["van_routes"])
    Z3 = c["c_F"] * len(g["van_routes"])
    Z4 = (c["pi_F"] * sum(E[i] for i in range(n) if res[i].startswith("FCS"))
          + c["pi_M"] * sum(E[k - 1] / p["eta"] for k in on_van))
    Z5 = c["c_W"] * float(np.sum(w * (C - r)))
    Z = Z1 + Z2 + Z3 + Z4 + Z5
    if abs(Z - g["Z_Rs"]) > 0.05:
        err.append(f"objective mismatch {Z:.2f} vs {g['Z_Rs']}")
    return J["name"], err, Z


if __name__ == "__main__":
    bad = 0
    for path in sorted(glob.glob(os.path.join(sys.argv[1], "*", "instance.json"))):
        name, err, Z = check(path)
        bad += bool(err)
        print(f"{name:12s} {'OK ' if not err else 'FAIL'} Z={Z:10.2f} {'; '.join(err[:3])}")
    print("all plans valid" if not bad else f"{bad} instance(s) with problems")
